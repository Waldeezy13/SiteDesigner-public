﻿using Autodesk.AutoCAD.DatabaseServices;
using SiteDesigner.Core;

namespace SiteDesigner.Plugin
{
    public static class AppState
    {
        public static ObjectId SiteBoundaryId { get; set; }

        public static SiteConfig Config { get; } = new SiteConfig();
    }
}
