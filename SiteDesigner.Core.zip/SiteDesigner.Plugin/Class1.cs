﻿namespace SiteDesigner.Plugin
{
    public class Class1
    {

    }
}
