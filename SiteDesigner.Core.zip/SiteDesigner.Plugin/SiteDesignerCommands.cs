﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;

[assembly: CommandClass(typeof(SiteDesigner.Plugin.SiteDesignerCommands))]

namespace SiteDesigner.Plugin
{
    public class SiteDesignerCommands
    {
        [CommandMethod("SDSTART")]
        public void StartPalette()
        {
            PaletteHost.ShowOrCreate();
        }

        [CommandMethod("SDSITESETUP")]
        public void SiteSetup()
        {
            var doc = Application.DocumentManager.MdiActiveDocument;
            var ed = doc.Editor;

            var peo = new PromptEntityOptions("\nSelect closed site boundary polyline: ");
            peo.SetRejectMessage("\nMust be a polyline.");
            peo.AddAllowedClass(typeof(Polyline), exactMatch: false);

            var per = ed.GetEntity(peo);
            if (per.Status != PromptStatus.OK) return;

            using (var tr = doc.TransactionManager.StartTransaction())
            {
                var ent = (Entity)tr.GetObject(per.ObjectId, OpenMode.ForRead);
                if (ent is Polyline pl && pl.Closed)
                {
                    AppState.SiteBoundaryId = per.ObjectId;
                    ed.WriteMessage("\nSite boundary stored. Open the palette with SDSTART to set parameters.");
                }
                else
                {
                    ed.WriteMessage("\nSelected polyline is not closed.");
                }
                tr.Commit();
            }
        }
    }
}
