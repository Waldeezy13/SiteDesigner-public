﻿using Autodesk.AutoCAD.Windows;

namespace SiteDesigner.Plugin
{
    public static class PaletteHost
    {
        private static PaletteSet? _ps;
        private static SiteDesigner.UI.SiteDesignerPanel? _panel;

        public static void ShowOrCreate()
        {
            if (_ps == null)
            {
                _ps = new PaletteSet("Site Designer")
                {
                    // Dock anywhere
                    DockEnabled = (DockSides)(-1)
                };

                _panel = new SiteDesigner.UI.SiteDesignerPanel();
                _panel.Bind(AppState.Config);
                _ps.Add("Design", _panel);
            }

            _ps.Visible = true;
        }

        public static SiteDesigner.UI.SiteDesignerPanel? Panel => _panel;
    }
}
